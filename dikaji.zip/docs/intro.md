---
sidebar_position: 1
---

# Pendahuluan

Mari belajar ibadah **sesuai Al Quran dan As Sunnah**.

## Mari Mulai

Hal pertama yang harus ditanamkan seorang muslim sebelum memulai ibadah adalah **meluruskan niat bahwa ibadah yang akan dilakukan adalah semata-mata hanya karena Allah**.

