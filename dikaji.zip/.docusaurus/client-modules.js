export default [
  require("C:\\laragon\\www\\dikaji\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\laragon\\www\\dikaji\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\laragon\\www\\dikaji\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("C:\\laragon\\www\\dikaji\\src\\css\\custom.css"),
];
