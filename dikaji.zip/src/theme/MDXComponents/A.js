import React from 'react';
import Link from '@docusaurus/Link';
export default function MDXA(props) {
  return <Link {...props} />;
}
