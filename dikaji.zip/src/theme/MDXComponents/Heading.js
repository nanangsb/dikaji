import React from 'react';
import Heading from '@theme/Heading';
export default function MDXHeading(props) {
  return <Heading {...props} />;
}
